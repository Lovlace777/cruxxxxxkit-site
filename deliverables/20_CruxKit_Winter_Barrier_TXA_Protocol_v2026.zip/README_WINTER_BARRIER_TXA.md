# CruxKit #20 — Autumn/Winter Retinoid + Ceramide 3:1:1 + TXA 4% Protocol

Includes:
1. 8-Week Autumn/Winter Skin Cycling Calendar pairing 0.1% Adapalene (Differin), CeraVe PM (Ceramides 1/3/6-II), La Roche-Posay Cicaplast Baume B5+ (Tribioma), Torriden 5D Hyaluronic Acid, and Anua 10% Niacinamide + 4% TXA.
2. Cold-weather TEWL (Transepidermal Water Loss) prevention checklist.
