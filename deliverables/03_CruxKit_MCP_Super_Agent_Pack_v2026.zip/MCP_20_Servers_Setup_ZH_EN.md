# 20 组 Claude Desktop & Cursor MCP 超级智能体配置指南
复制 `claude_desktop_config.json` 到本地配置目录即可赋予 AI 读写文件、检索网页与操作数据库能力。