# The Solo OS · 一人公司操作中枢与联盟营销台账
导入 CSV 至 Notion 即可启用。