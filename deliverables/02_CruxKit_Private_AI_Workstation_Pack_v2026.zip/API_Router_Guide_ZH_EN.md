# 零封号个人 AI 工作台部署手册 (OpenRouter + DeepSeek + LobeChat)
1. 注册 OpenRouter 或 SiliconFlow 获取官方 API Key
2. 一键部署 LobeChat 至 Cloudflare Pages / Zeabur
3. 导入本包中的 50 个专家智能体 JSON