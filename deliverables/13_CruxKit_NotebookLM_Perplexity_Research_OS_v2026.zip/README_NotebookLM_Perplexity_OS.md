# CruxKit* — NotebookLM & Perplexity Deep-Research Operating System (v2026)

## Included Modules
1. `01_Perplexity_Pro_Citation_Prompts.json` — 45 zero-hallucination academic, market, and competitor audit prompts.
2. `02_NotebookLM_Audio_Podcast_Synthesis_Guide.md` — Turn 50 PDFs/URLs into structured bilingual briefing scripts and lead magnets.
3. `03_Competitor_Affiliate_Matrix_Scraper_Spec.md` — How to extract high-converting affiliate programs from any niche authority site.
