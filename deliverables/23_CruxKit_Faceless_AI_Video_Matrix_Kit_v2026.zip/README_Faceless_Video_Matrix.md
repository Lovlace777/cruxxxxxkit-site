# CruxKit #22 — HeyGen + Synthesia + OpusClip + CapCut 90-Shorts/Mo Matrix

Includes 30 bilingual hook scripts, HeyGen API webhook payload templates, and FFmpeg batch normalization scripts.
