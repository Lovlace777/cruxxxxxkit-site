# Bilingual Affiliate Disclosure Templates

## English (FTC 16 CFR Part 255 Compliant)
> **Editorial Independence & Partner Disclosure:** Every product in the CruxKit* stack is independently benchmarked. When you route through our `/go/` links, we may earn a partner commission at zero extra cost to you — and often unlock exclusive partner credits.

## 中文（符合《广告法》与平台合规声明）
> **独立评测与合作伙伴声明：** CruxKit* 推荐的每一款工具与功效配方均经过独立实测。当您通过站内 `/go/` 专属链接注册或购买时，我们可能会获得品牌方返佣（不会增加您的任何额外费用，且通常附带专属算力或折扣权益）。
