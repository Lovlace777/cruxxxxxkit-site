# CruxKit* — High-Converting Affiliate Comparison Matrix & SEO Template Pack (v2026)

## Included Modules
1. `01_Comparison_Table_HTML_Component.html` — Drop-in responsive verdict table with `/go/` partner pills and score badges.
2. `02_FTC_and_CN_Ad_Law_Disclosure_Snippets.md` — Compliant bilingual affiliate disclosure banners that build reader trust.
3. `03_High_Intent_Buyer_Keyword_Formulas.csv` — 60 'vs', 'alternative', and 'pricing audit' title templates with 8%+ CTR.
