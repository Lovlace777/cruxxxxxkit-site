export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    const slug = url.pathname.replace(/^\/go\//, '').replace(/\/$/, '');
    const map = {
      make: 'https://www.make.com/en/register?pc=cruxkit',
      n8n: 'https://n8n.partnerlinks.io/cruxkit',
      spaceship: 'https://www.spaceship.com/?ref=cruxkit'
    };
    const target = map[slug];
    if (!target) return new Response('Not Found', { status: 404 });
    return Response.redirect(target, 302);
  }
};
