# CruxKit* — Cloudflare Workers + R2 Zero-Egress Edge Kit (v2026)

## Included Modules
1. `worker-affiliate-router.js` — Ultra-fast Cloudflare Worker for `/go/:slug` click analytics, UTM preservation, and sub-ID injection.
2. `worker-r2-signed-delivery.js` — Zero-egress HMAC-signed download links for delivering `.ZIP` digital kits from Cloudflare R2.
3. `spaceship-dns-cloudflare-playbook.md` — Step-by-step DNS & SSL hardening guide for custom domains.
