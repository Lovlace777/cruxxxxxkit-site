# $4/月 VPS 无限次运行 n8n AI 工作流私有化部署手册
含 Docker Compose + Caddy 自动 HTTPS 证书 + 每日定时备份脚本。