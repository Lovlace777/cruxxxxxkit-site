# The Solo OS · 一人公司与联盟营销操作中枢 (Notion 模版)

## 1. 今日专注规则 (The 3-Slot "NOW" Rule)
- 永远只允许 **最多 3 个项目** 处于 `NOW` 状态。
- 每个 `NOW` 项目必须写明 **下一步唯一具体动作（Next Physical Action）**。

## 2. 每周五 16:00 二十分钟复盘清单 (Friday 20-Min Reset)
- [ ] 清空本周临时收集箱（Inbox Zero）
- [ ] 检查 `01_Affiliate_CRM_Ledger.csv` 中的外链点击与转化数据
- [ ] 归档已完成卡片，并设定下周一早上的第一个动作
