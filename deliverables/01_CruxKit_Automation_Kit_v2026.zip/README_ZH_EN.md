# 01 The Automation Kit (Make & n8n)
Includes 15 ready-to-import JSON automation blueprints with bilingual setup guides.