#!/usr/bin/env bash
curl -s https://geo.brdtest.com/mygeo.json | jq .
