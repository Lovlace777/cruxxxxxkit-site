create table public.subscriptions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users not null,
  stripe_status text default 'active',
  created_at timestamptz default now()
);
alter table public.subscriptions enable row level security;
