# CruxKit #18 — Gemini 4 Argon, Gemini Omni 1.2 Flash & Nano Banana 2.1 Video Kit

Includes:
1. Storyboard & first/last-frame prompt templates for `google/gemini-omni-1.2-flash` and `google/gemini-nano-banana-2.1`.
2. HeyGen Avatar (`?via=xing`) + ElevenLabs v3 bilingual dubbing automation pipeline.
