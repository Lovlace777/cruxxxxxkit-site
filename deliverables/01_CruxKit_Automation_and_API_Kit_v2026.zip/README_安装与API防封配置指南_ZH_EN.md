# CruxKit Automation & Private AI Workstation Kit (2026 Edition)

## 包含内容 (What's Inside)
1. `01_n8n_Workflows/` — 可直接导入 n8n (Cloud 或 Docker 自托管版) 的自动化工作流 `.json` 源文件。
2. `02_Make_Blueprints/` — 可直接导入 Make.com (Import Blueprint) 的可视化路由蓝图。
3. `03_AI_Workstation_Config/` — 零封号风险的官方 API 聚合中转（OpenRouter / DeepSeek / SiliconFlow）+ LobeChat 预设专家智能体配置文件。

## 3 分钟快速导入步骤
- **n8n 导入**：打开 n8n 画布 -> 点击右上角 `...` -> `Import from File` -> 选择本包中的 `.json` 文件，将 API Key 替换为你的密钥即可运行。
- **Make.com 导入**：登录 Make.com -> 新建 Scenario -> 点击底部工具栏 `...` -> `Import Blueprint`。
