# CruxKit* — Retinoid & Acid Tolerance 12-Week Ramp-Up Protocol (v2026)

## Included Modules
1. `12_Week_Retinoid_Ladder_Schedule.csv` — Progressive frequency ladder (1x/wk -> 2x/wk -> every other night) for Adapalene 0.1%, Retinal 0.05%, and Tretinoin 0.025%.
2. `Sandwich_Buffer_and_TEWL_Rescue_Guide.md` — How to pair La Roche-Posay Cicaplast B5+ and Ceramide lotions to eliminate retinoid dermatitis.
