# CruxKit #17 — DeepSeek V4.1-Flash-1017 & GPT-6.1 Smart Router Pack (Nov 2026)

Includes production OpenRouter & LiteLLM routing rules for:
- `deepseek/deepseek-v4.1-flash-1017` ($0.15/M in, $0.60/M out, 1M context)
- `deepseek/deepseek-v4.1-flash` ($0.04/M in, $0.50/M out, 1M context)
- `openai/gpt-6.1-terra-pro` ($1.00/M in, $5.00/M out, 1.05M context)
- `openai/gpt-6.1-sol-pro` ($2.00/M in, $10.00/M out, 1.05M context)
- `openai/gpt-6-luna` ($0.10/M in, $0.50/M out, 1.05M context)
- `google/gemini-4-argon` ($2.00/M in, $10.00/M out, 1M context)
- `google/gemini-3.8-flash` ($0.83/M in, $4.12/M out, 1M context)
- `anthropic/claude-sonnet-5.5` ($2.00/M in, $10.00/M out, 1M context)
- `anthropic/claude-haiku-5.5` ($0.10/M in, $0.50/M out, 1M context)
