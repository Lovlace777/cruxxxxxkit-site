# 50 组中英双语高转化评测与脚本提示词库
适配 Claude 3.7、Gemini 与 DeepSeek。