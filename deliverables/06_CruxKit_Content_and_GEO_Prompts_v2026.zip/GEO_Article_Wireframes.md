# 6 套被 AI 搜索引擎 (ChatGPT / Perplexity / 秘塔) 优先引用的评测骨架
1. 首屏 30 秒结论框 (TL;DR Verdict)
2. 硬核实测参数表 (Markdown Table)
3. 真实优缺点边界
