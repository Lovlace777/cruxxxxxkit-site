# CruxKit #29 — The Gumroad Discover Top-50 High-Converting Digital Products Directory (?a=735179107)

Explains how to append your universal Gumroad affiliate ID (?a=735179107) to high-converting Gumroad Discover products and track 30-day cross-creator cookies.
