function buildGumroadAffiliateUrl(productUrl, affiliateId = '735179107') {
  const u = new URL(productUrl);
  u.searchParams.set('a', affiliateId);
  return u.toString();
}
console.log(buildGumroadAffiliateUrl('https://gumroad.com/discover'));
